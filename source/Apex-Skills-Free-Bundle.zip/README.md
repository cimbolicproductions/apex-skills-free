# Apex Skills: free complete download

67 skill files and packs: 24 featured catalog products, 38 unlisted catalog products, and 5 SEO additions. This includes all 62 catalog products. Some packs contain multiple workflows, including related copies of standalone skills; this is a count of product files and packs, not unique workflows. No payment or email is required for this download.

## New additions

- AEO and GEO: aeo-and-geo.zip
- Keyword Research: seo-keyword-research.md
- Long-tail Keyword Research: seo-longtail-keywords.md
- Bing Places: seo-bing-places.md
- Search Console Analysis: seo-search-console.md

AEO and GEO includes its Python audit script, evidence reference and related SEO workflows. The Google Business Profile workflow is refreshed to remove outdated Q&A-seeding instructions.

## Install or use a skill

1. Unzip this download into a folder you choose.
2. Pick the skill you need. Open its markdown file, or unzip its individual pack and read SKILL.md. Keep supporting scripts, references and templates together.
3. For an AI chat, attach the skill's markdown and relevant references, describe your task, and ask the assistant to apply the workflow.
4. For a coding assistant, give it the selected file or extracted pack and ask: "Install this skill for future sessions using your supported skill location, preserve its support files, and tell me how to invoke it."

For manual Claude Code installation, a single markdown skill belongs at ~/.claude/skills/<skill-name>/SKILL.md. A pack that already contains a named skill folder can be extracted into ~/.claude/skills/. Packs with SKILL.md at the root belong inside a named skill folder. Other assistants may use different locations. You do not need to install every skill.

## Verify contents

MANIFEST.json lists every included product filename, byte count and SHA256. Existing product licenses and attributions remain with their files; new SEO additions retain MIT metadata. This archive includes only approved product artifacts, not local accounts, configuration or customer records.

Share page: https://apexskills.dev/free-bundle
Direct ZIP: https://apexskills.dev/api/free-bundle
